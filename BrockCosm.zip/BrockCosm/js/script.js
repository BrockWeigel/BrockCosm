function myFunction(){


    self = this;
    self.Var = ko.observable();
    self.Var("Yoyo");

    $('#thingy').css('background-color', 'red');
    document.getElementById('thingy').innerHTML = self.Var();

}

$(document).ready(function(){
	$("#nav-placeholder").load("navbar.html");
	$("#demo").val("window.location.pathname");
});

ko.applyBindings(new myFunction());